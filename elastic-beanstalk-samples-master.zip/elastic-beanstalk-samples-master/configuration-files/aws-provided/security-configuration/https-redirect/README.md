```
###################################################################################################
#### These configuration files configures the proxy server that runs in front of your application
#### to redirect HTTP requests on port 80 to the same path on HTTPS/443.
####
#### Please browse to the folder matching the platform for your environment for further information.
###################################################################################################
```
