```
For Java Tomcat environments running the default Apache proxy server browse to:

https-redirect-java-tomcat-apache-2.4


For Java Tomcat environments running the Apache 2.2  proxy server browse to:

https-redirect-java-tomcat-apache-2.2


For Java Tomcat environments configured to use the Nginx proxy browse to:

https-redirect-nginx-java-tomcat
```
