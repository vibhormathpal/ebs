```
For Load Balanced Ruby Passenger environments browse to:

https-redirect-load-balanced-ruby-passenger

For Single Instance Ruby Passenger environments browse to:

https-redirect-single-instance-ruby-passenger
```
