```
###################################################################################################
#### These configuration files configures Apache or Nginx for an environment to rate limit the
#### amount of unique inbound connections per instance in that environment.
####
#### Please browse to the folder matching the platform for your environment for further information.
###################################################################################################
```
